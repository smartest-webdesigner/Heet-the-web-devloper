student_name = input("Enter Student Name: ")
book_id = input("Enter Book ID: ")
book_name = input("Enter Book Name: ")

print("/n----- Library Record -----")
print("Student Name :", student_name)
print("Book ID :", book_id)
print("Book Name :", book_name)

# Option to add another book
choice = input("\nDo you want to add another book? (yes/no): ")

if choice == "yes":
    book_id = input("Enter New Book ID: ")
    book_name = input("Enter New Book Name: ")

    print("\n----- New Book Record -----")
    print("Student Name :", student_name)
    print("Book ID :", book_id)
    print("Book Name :", book_name)

