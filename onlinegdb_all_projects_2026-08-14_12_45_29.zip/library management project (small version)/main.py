student = input("Student: ")
books = [[input("ID: "), input("Name: ")] for _ in range(3)]
if input("Add? ").lower() == "yes":
    books.append([input("ID: "), input("Name: ")])
if input("Delete? ").lower() == "yes":
    d = input("Name: ")
    books = [b for b in books if b[1] != d]
print("\nStudent:", student)
for i, b in enumerate(books, 1):
    print(f"Book {i}: {b[0]} {b[1]}")




