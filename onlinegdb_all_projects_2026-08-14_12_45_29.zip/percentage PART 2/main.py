name= input("enter your name:")
maths_marks = input("Enter your maths marks:")
sci_marks = input("Enter your science marks:")
eng_marks = input("Enter your English marks:")
marathi_marks = input("Enter your marathi marks:")
hindi_marks = input("Enter your hindi marks:")
sst_marks = input("Enter your sst marks:")
percentage = ((int(maths_marks)+ int(sci_marks)+int(eng_marks)+int(marathi_marks)+int(hindi_marks)+int(sst_marks)))/600*100
print(name, "your percentage is",percentage)
