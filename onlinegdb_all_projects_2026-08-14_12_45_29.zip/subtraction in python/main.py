a = 15
b = 19
c = a - b ,
print("Subtraction:", c )