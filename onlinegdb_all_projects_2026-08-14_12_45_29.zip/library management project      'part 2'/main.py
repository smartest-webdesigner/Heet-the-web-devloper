student_name = input("Enter Student Name: ")

# Book 1
book1_id = input("Enter Book 1 ID: ")
book1_name = input("Enter Book 1 Name: ")

# Book 2
book2_id = input("Enter Book 2 ID: ")
book2_name = input("Enter Book 2 Name: ")

# Book 3
book3_id = input("Enter Book 3 ID: ")
book3_name = input("Enter Book 3 Name: ")

print("\n----- Library Record -----")
print("Student Name :", student_name)

print("\nBook 1")
print("Book ID :", book1_id)
print("Book Name :", book1_name)

print("\nBook 2")
print("Book ID :", book2_id)
print("Book Name :", book2_name)

print("\nBook 3")
print("Book ID :", book3_id)
print("Book Name :", book3_name)

# Option to add another book
choice = input("\nDo you want to add another book? (yes/no): ")

book_id = ""
book_name = ""

if choice.lower() == "yes":
    book_id = input("Enter New Book ID: ")
    book_name = input("Enter New Book Name: ")

    print("\n----- New Book Record -----")
    print("Student Name :", student_name)
    print("Book ID :", book_id)
    print("Book Name :", book_name)

# Option to delete a book
delete = input("\nDo you want to delete any book? (yes/no): ")

if delete.lower() == "yes":
    delete_name = input("Which book do you want to delete? Enter Book Name: ")

    if delete_name == book1_name:
        book1_id = ""
        book1_name = ""
        print(delete_name, "has been deleted successfully!")

    elif delete_name == book2_name:
        book2_id = ""
        book2_name = ""
        print(delete_name, "has been deleted successfully!")

    elif delete_name == book3_name:
        book3_id = ""
        book3_name = ""
        print(delete_name, "has been deleted successfully!")

    elif choice.lower() == "yes" and delete_name == book_name:
        book_id = ""
        book_name = ""
        print(delete_name, "has been deleted successfully!")

    else:
        print("Book not found!")

else:
    print("No Book Deleted.")

print("\n----- Updated Library Record -----")
print("Student Name :", student_name)

print("\nBook 1")
print("Book ID :", book1_id)
print("Book Name :", book1_name)

print("\nBook 2")
print("Book ID :", book2_id)
print("Book Name :", book2_name)

print("\nBook 3")
print("Book ID :", book3_id)
print("Book Name :", book3_name)

if choice.lower() == "yes" and book_name != "":
    print("\nAdded Book")
    print("Book ID :", book_id)
    print("Book Name :", book_name)