a = 26
b = 15
c = a + b , 
print("Addition", c)