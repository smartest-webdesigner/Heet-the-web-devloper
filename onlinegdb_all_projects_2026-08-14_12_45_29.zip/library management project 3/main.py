student_name = input("Enter Student Name: ")

books = []

# Enter Initial Books
num = int(input("How many books do you want to issue initially? "))

for i in range(num):
    print(f"\nEnter Details of Book {i+1}")
    book = {
        "id": input("Book ID: "),
        "name": input("Book Name: ")
    }
    books.append(book)

# Main Menu
while True:
    print("\n========== LIBRARY MENU ==========")
    print("1. View Books")
    print("2. Add Book")
    print("3. Delete Book")
    print("4. Search Book")
    print("5. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        print("\n----- Library Record -----")
        print("Student Name:", student_name)

        if len(books) == 0:
            print("No books available.")
        else:
            for i, book in enumerate(books, start=1):
                print(f"\nBook {i}")
                print("Book ID:", book["id"])
                print("Book Name:", book["name"])

    elif choice == "2":
        print("\nAdd New Book")
        new_book = {
            "id": input("Enter Book ID: "),
            "name": input("Enter Book Name: ")
        }
        books.append(new_book)
        print("Book added successfully!")

    elif choice == "3":
        delete_name = input("Enter Book Name to Delete: ")

        found = False
        for book in books:
            if book["name"].lower() == delete_name.lower():
                books.remove(book)
                print("Book deleted successfully!")
                found = True
                break

        if not found:
            print("Book not found!")

    elif choice == "4":
        search_name = input("Enter Book Name to Search: ")

        found = False
        for book in books:
            if book["name"].lower() == search_name.lower():
                print("\nBook Found")
                print("Book ID:", book["id"])
                print("Book Name:", book["name"])
                found = True
                break

        if not found:
            print("Book not found!")

    elif choice == "5":
        print("\nThank you for using Library Management System!")
        break

    else:
        print("Invalid choice! Please try again.")