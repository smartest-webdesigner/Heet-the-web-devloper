num = int(input("Enter a number: "))
for i in range(1, 10):
    print(num * i)