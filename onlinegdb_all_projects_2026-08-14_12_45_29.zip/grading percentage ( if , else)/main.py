percentage = float(input("Enter Percentage: "))
if percentage>= 90:
    print("Grade A")
elif percentage >= 75:
    print("Grade B")
elif percentage >= 60:
    print("Grade C")
elif percentage >= 35:
    print("Grade D")
else:
    print("Fail")
