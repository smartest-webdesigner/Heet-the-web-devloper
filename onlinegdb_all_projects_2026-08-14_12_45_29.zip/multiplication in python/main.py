a = 64525566
b = 685763487548798
c = a * b ,
print("mutiplication:" , c )