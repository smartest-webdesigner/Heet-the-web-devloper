for i in range (1,11):
    print("cube of",i,"=",i*i*i)