name= input("Enter your name :")
maths_marks= input("enter your maths marks :")
eng_marks= input("enter your english marks :")
sci_marks= input ("enter your science :")
mar_marks= input ("enter your marathi :")
hin_marks= input ("enter your hindi :")
percentage= ((int(maths_marks)+ int(eng_marks)+ int(sci_marks) + int(mar_marks)+ int(hin_marks)))/500*100
print(name, "your percentage is :", percentage)
percentage= float(input("enter your percentage to know grade which you have got:"))
if percentage >= 90:
    print("A Grade")
elif percentage >= 75:
    print("B Grade")
elif percentage >= 60:
    print("C Grade")
elif percentage >= 45:
    print("D Grade")
else : 
    print("Fail")