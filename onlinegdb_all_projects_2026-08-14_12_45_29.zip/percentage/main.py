name= input("enter your name:")
maths_marks = input("Enter your maths marks:")
sci_marks = input("Enter your science marks:")
eng_marks = input("Enter your English marks:")
percentage = ((int(maths_marks)+ int(sci_marks)+int(eng_marks)))/300*100
print(name, "your percentage is",percentage)


